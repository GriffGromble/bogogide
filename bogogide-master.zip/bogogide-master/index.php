<?php
require "settings/init.php"; // Ensure this path is correct
?>
<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="utf-8">
    <title>Book Quiz</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/styles.css" rel="stylesheet" type="text/css">
    <script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</head>
<style>
    .progress {
        height: 20px;
        width: 80%;
        margin: 0 auto;
    }
    .progress-bar {
        background-color: #dc3545;
    }
</style>
<body>
<div class="container text-center mt-5">
    <!-- Step 1: Start Quiz -->
    <div id="quiz-start" class="quiz-step">
        <button id="startQuiz" class="btn btn-primary btn-lg">Tag Quiz</button>
    </div>

    <!-- Quiz Questions -->
    <div id="quiz-question1" class="quiz-step" style="display: none;">
        <h2>Hvem er bogen til?</h2>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(2)">Mig selv</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(2)">For en anden</button>
    </div>

    <div id="quiz-question2" class="quiz-step" style="display: none;">
        <h2>Hvad leder du efter i en bog?</h2>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(3)">Romantik og stærke følelser</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(3)">Mystik og spænding</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(3)">Fantasi og eventyr</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(3)">Historie og viden</button>
    </div>

    <div id="quiz-question3" class="quiz-step" style="display: none;">
        <h2>Hvilket miljø foretrækker du i en bog?</h2>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(4)">A) Små, hyggelige byer</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(4)">B) Mørke kroge</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(4)">C) En ny verden med magi</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(4)">D) Historiske byer</button>
    </div>

    <div id="quiz-question4" class="quiz-step" style="display: none;">
        <h2>Hvordan har du det med overnaturlige elementer i bøger?</h2>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(5)">A) Kun hvis der er kærlighed involveret</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(5)">B) Elsker det! Jo mere mystisk, desto bedre</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(5)">C) Fantastisk! Drager og magi er velkomne</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(5)">D) Helst realistisk – men en smule mystik kan gå an</button>
    </div>

    <div id="quiz-question5" class="quiz-step" style="display: none;">
        <h2>Hvilken karakter trækker dig mest?</h2>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(6)">A) En forelsket helt eller heltinde</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(6)">B) En detektiv eller nogen med hemmelige evner</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(6)">C) En troldmand eller eventyrer</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(6)">D) En historisk figur eller en person fra virkeligheden</button>
    </div>

    <div id="quiz-question6" class="quiz-step" style="display: none;">
        <h2>Hvordan skal bogen få dig til at føle?</h2>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(7)">A) Berørt og måske lidt sentimental</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(7)">B) Spændt og lidt paranoid</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(7)">C) Fortryllet og fascineret af nye verdener</button>
        <button class="btn btn-secondary w-50 my-2" onclick="goToNextQuestion(7)">D) Klogere og mere oplyst</button>
    </div>

    <div id="quiz-question7" class="quiz-step" style="display: none;">
        <h2>Hvilket citat tiltrækker dig mest?</h2>
        <button class="btn btn-secondary w-50 my-2" onclick="showResult()">“Den største lykke i livet er kærlighed.”</button>
        <button class="btn btn-secondary w-50 my-2" onclick="showResult()">“Intet er, som det ser ud.”</button>
        <button class="btn btn-secondary w-50 my-2" onclick="showResult()">“Verden er fuld af magiske ting.”</button>
        <button class="btn btn-secondary w-50 my-2" onclick="showResult()">“Historien gentager sig.”</button>
    </div>

    <!-- Final Step: Show Book Recommendation -->
    <div id="quiz-result" class="quiz-step" style="display: none;">
        <h2>Recommended Book for You:</h2>
        <div id="bookRecommendation">
            <?php
            // Fetch a random book
            $books = $db->sql("SELECT * FROM bøger ORDER BY RAND() LIMIT 1");
            foreach ($books as $book) {
                ?>
                <div class="card w-100">
                    <div class="card-header">
                        <?php echo htmlspecialchars($book->bogNavn); ?>
                    </div>
                    <div class="card-body">
                        <p>Author: <?php echo htmlspecialchars($book->bogForfatter); ?></p>
                        <p><?php echo htmlspecialchars($book->bogBeskrivelse); ?></p>
                        <img src="data:image/jpeg;base64,<?php echo base64_encode($book->bogBillede); ?>" alt="Book Image" style="max-width:100%; height:auto;">
                    </div>
                    <div class="card-footer text-muted">
                        Price: <?php echo number_format($book->bogPris, 2, ',', '.'); ?> DKK
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
        <button class="btn btn-primary mt-3" onclick="restartQuiz()">Tag quiz igen</button>
    </div>

    <!-- Move progress bar below all questions and quiz results -->
    <div class="progress my-4">
        <div id="quizProgressBar" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
    </div>
</div>

<script>
    const totalQuestions = 7;

    document.getElementById("startQuiz").addEventListener("click", function () {
        document.getElementById("quiz-start").style.display = "none";
        document.getElementById("quiz-question1").style.display = "block";
        updateProgressBar(1);
    });

    function goToNextQuestion(questionNumber) {
        document.querySelectorAll('.quiz-step').forEach((step) => {
            step.style.display = "none"; // Hide all steps
        });

        // Show the specified question
        document.getElementById("quiz-question" + questionNumber).style.display = "block";
        updateProgressBar(questionNumber);
    }

    function updateProgressBar(currentQuestion) {
        const progress = Math.floor((currentQuestion / totalQuestions) * 100);
        const progressBar = document.getElementById("quizProgressBar");
        progressBar.style.width = progress + "%";
        progressBar.setAttribute("aria-valuenow", progress);
    }

    function showResult() {
        document.querySelectorAll('.quiz-step').forEach((step) => {
            step.style.display = "none";
        });
        document.getElementById("quiz-result").style.display = "block";
        updateProgressBar(totalQuestions);
    }

    function restartQuiz() {
        document.getElementById("quiz-result").style.display = "none";
        document.getElementById("quiz-start").style.display = "block";
        updateProgressBar(0);
    }
</script>
</body>
</html>
